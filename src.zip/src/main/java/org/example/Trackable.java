package org.example;

public interface Trackable {
    public static void trackProgress() {

    }
}
