package org.example;

import java.util.List;

public class TaskManager {
    private List<Task> allTask;
    ReminderService reminders = new ReminderService();

    public static void addTask() {

    }

    public static void deleteTask() {

    }

    public static void editTask() {

    }

    public static void markTaskAsCompleted() {

    }


    public static void filterTaskByCategory() {

    }

    public static String viewTaskByCategory(List<Task> tasks) {

    }

    public static String searchTask(Task task) {

    }

    public static void organiseTaskByDate(List<Task> tasks) {

    }

    public static void prioritizeTasks(String task) {

    }

    public static boolean loadTaskFromFile(String string) {

    }


}
