package org.example;

public interface Schedulable {
    static void schedule() {
        System.out.println("Scheduling...");
    }
}
