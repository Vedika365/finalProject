package org.example;

public interface Notifiable {

    /**
     * Sends a notification with default behavior
     */
    default void sendNotifications() {
         System.out.println("Sending notification : You hava a new message! ");
    }
}
