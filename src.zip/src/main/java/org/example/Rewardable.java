package org.example;

public interface Rewardable {

    /**
     * calculates the reward
     */
    default void calculateReward() {
      int basePoints = 10;
        System.out.println("Reward calculated : " + basePoints + "points earned!");
    }
}
